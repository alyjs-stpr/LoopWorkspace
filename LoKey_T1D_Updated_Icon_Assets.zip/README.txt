LoKey T1D — Updated artwork (white background removed)

Source: transparent version of your approved LO blood-drop logo.
Images for Apple app icons require an opaque background, so icon assets use dark navy (#03142C). The separate transparent logo file is provided outside this ZIP.

How to install in your LoopWorkspace fork:
1. Extract this ZIP on your PC.
2. Replace the contents of these two directories in your fork:
   OverrideAssetsLoop.xcassets/AppIcon.appiconset/
   OverrideAssetsWatchApp.xcassets/AppIcon.appiconset/
   (Keep filenames and Contents.json as provided.)
3. In LoopConfigOverride.xcconfig, set:
   MAIN_APP_DISPLAY_NAME = LoKey T1D
   Don't change the Bundle ID.
4. Commit the changes to your GitHub fork.
5. Actions > 4. Build Loop Manual on main; wait for TestFlight processing and update the app.

Back up the working Loop app and its settings prior to updating, and do not delete the app or disrupt active pump delivery.
